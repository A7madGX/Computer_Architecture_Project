/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Xillics/ALUM/ALUTest.vhd";



static void work_a_1599699025_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int64 t9;
    unsigned char t10;
    unsigned char t11;
    unsigned int t12;
    unsigned char t13;
    unsigned char t14;
    char *t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    char *t20;
    unsigned char t21;
    unsigned char t22;

LAB0:    t1 = (t0 + 3312U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 6124);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(66, ng0);
    t2 = (t0 + 6156);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 6188);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(68, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 6192);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6197);
    t11 = 1;
    if (32U == 32U)
        goto LAB13;

LAB14:    t11 = 0;

LAB15:    if (t11 == 1)
        goto LAB10;

LAB11:    t10 = (unsigned char)0;

LAB12:    if (t10 == 0)
        goto LAB8;

LAB9:    xsi_set_current_line(72, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB21:    *((char **)t1) = &&LAB22;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    t7 = (t0 + 6229);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB9;

LAB10:    t7 = (t0 + 1992U);
    t8 = *((char **)t7);
    t13 = *((unsigned char *)t8);
    t14 = (t13 == (unsigned char)2);
    t10 = t14;
    goto LAB12;

LAB13:    t12 = 0;

LAB16:    if (t12 < 32U)
        goto LAB17;
    else
        goto LAB15;

LAB17:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB14;

LAB18:    t12 = (t12 + 1);
    goto LAB16;

LAB19:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 6235);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 6267);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(77, ng0);
    t2 = (t0 + 6299);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(78, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB25:    *((char **)t1) = &&LAB26;
    goto LAB1;

LAB20:    goto LAB19;

LAB22:    goto LAB20;

LAB23:    xsi_set_current_line(79, ng0);
    t2 = (t0 + 6303);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(80, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6308);
    t11 = 1;
    if (32U == 32U)
        goto LAB32;

LAB33:    t11 = 0;

LAB34:    if (t11 == 1)
        goto LAB29;

LAB30:    t10 = (unsigned char)0;

LAB31:    if (t10 == 0)
        goto LAB27;

LAB28:    xsi_set_current_line(82, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB40:    *((char **)t1) = &&LAB41;
    goto LAB1;

LAB24:    goto LAB23;

LAB26:    goto LAB24;

LAB27:    t7 = (t0 + 6340);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB28;

LAB29:    t7 = (t0 + 1992U);
    t8 = *((char **)t7);
    t13 = *((unsigned char *)t8);
    t14 = (t13 == (unsigned char)2);
    t10 = t14;
    goto LAB31;

LAB32:    t12 = 0;

LAB35:    if (t12 < 32U)
        goto LAB36;
    else
        goto LAB34;

LAB36:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB33;

LAB37:    t12 = (t12 + 1);
    goto LAB35;

LAB38:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 6346);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 6378);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 6410);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(88, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB44:    *((char **)t1) = &&LAB45;
    goto LAB1;

LAB39:    goto LAB38;

LAB41:    goto LAB39;

LAB42:    xsi_set_current_line(89, ng0);
    t2 = (t0 + 6414);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(90, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6419);
    t14 = 1;
    if (32U == 32U)
        goto LAB57;

LAB58:    t14 = 0;

LAB59:    if (t14 == 1)
        goto LAB54;

LAB55:    t13 = (unsigned char)0;

LAB56:    if (t13 == 1)
        goto LAB51;

LAB52:    t11 = (unsigned char)0;

LAB53:    if (t11 == 1)
        goto LAB48;

LAB49:    t10 = (unsigned char)0;

LAB50:    if (t10 == 0)
        goto LAB46;

LAB47:    xsi_set_current_line(92, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB65:    *((char **)t1) = &&LAB66;
    goto LAB1;

LAB43:    goto LAB42;

LAB45:    goto LAB43;

LAB46:    t7 = (t0 + 6451);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB47;

LAB48:    t7 = (t0 + 1992U);
    t20 = *((char **)t7);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)2);
    t10 = t22;
    goto LAB50;

LAB51:    t7 = (t0 + 1832U);
    t15 = *((char **)t7);
    t18 = *((unsigned char *)t15);
    t19 = (t18 == (unsigned char)2);
    t11 = t19;
    goto LAB53;

LAB54:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t16 = *((unsigned char *)t8);
    t17 = (t16 == (unsigned char)3);
    t13 = t17;
    goto LAB56;

LAB57:    t12 = 0;

LAB60:    if (t12 < 32U)
        goto LAB61;
    else
        goto LAB59;

LAB61:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB58;

LAB62:    t12 = (t12 + 1);
    goto LAB60;

LAB63:    xsi_set_current_line(95, ng0);
    t2 = (t0 + 6457);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(96, ng0);
    t2 = (t0 + 6489);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(97, ng0);
    t2 = (t0 + 6521);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(98, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB69:    *((char **)t1) = &&LAB70;
    goto LAB1;

LAB64:    goto LAB63;

LAB66:    goto LAB64;

LAB67:    xsi_set_current_line(99, ng0);
    t2 = (t0 + 6525);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(100, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6530);
    t14 = 1;
    if (32U == 32U)
        goto LAB82;

LAB83:    t14 = 0;

LAB84:    if (t14 == 1)
        goto LAB79;

LAB80:    t13 = (unsigned char)0;

LAB81:    if (t13 == 1)
        goto LAB76;

LAB77:    t11 = (unsigned char)0;

LAB78:    if (t11 == 1)
        goto LAB73;

LAB74:    t10 = (unsigned char)0;

LAB75:    if (t10 == 0)
        goto LAB71;

LAB72:    xsi_set_current_line(102, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB90:    *((char **)t1) = &&LAB91;
    goto LAB1;

LAB68:    goto LAB67;

LAB70:    goto LAB68;

LAB71:    t7 = (t0 + 6562);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB72;

LAB73:    t7 = (t0 + 1992U);
    t20 = *((char **)t7);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)3);
    t10 = t22;
    goto LAB75;

LAB76:    t7 = (t0 + 1832U);
    t15 = *((char **)t7);
    t18 = *((unsigned char *)t15);
    t19 = (t18 == (unsigned char)3);
    t11 = t19;
    goto LAB78;

LAB79:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t16 = *((unsigned char *)t8);
    t17 = (t16 == (unsigned char)2);
    t13 = t17;
    goto LAB81;

LAB82:    t12 = 0;

LAB85:    if (t12 < 32U)
        goto LAB86;
    else
        goto LAB84;

LAB86:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB83;

LAB87:    t12 = (t12 + 1);
    goto LAB85;

LAB88:    xsi_set_current_line(105, ng0);
    t2 = (t0 + 6568);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(106, ng0);
    t2 = (t0 + 6600);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(107, ng0);
    t2 = (t0 + 3888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 6632);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(109, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB94:    *((char **)t1) = &&LAB95;
    goto LAB1;

LAB89:    goto LAB88;

LAB91:    goto LAB89;

LAB92:    xsi_set_current_line(110, ng0);
    t2 = (t0 + 6636);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6641);
    t14 = 1;
    if (32U == 32U)
        goto LAB107;

LAB108:    t14 = 0;

LAB109:    if (t14 == 1)
        goto LAB104;

LAB105:    t13 = (unsigned char)0;

LAB106:    if (t13 == 1)
        goto LAB101;

LAB102:    t11 = (unsigned char)0;

LAB103:    if (t11 == 1)
        goto LAB98;

LAB99:    t10 = (unsigned char)0;

LAB100:    if (t10 == 0)
        goto LAB96;

LAB97:    xsi_set_current_line(113, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB115:    *((char **)t1) = &&LAB116;
    goto LAB1;

LAB93:    goto LAB92;

LAB95:    goto LAB93;

LAB96:    t7 = (t0 + 6673);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB97;

LAB98:    t7 = (t0 + 1992U);
    t20 = *((char **)t7);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)2);
    t10 = t22;
    goto LAB100;

LAB101:    t7 = (t0 + 1832U);
    t15 = *((char **)t7);
    t18 = *((unsigned char *)t15);
    t19 = (t18 == (unsigned char)3);
    t11 = t19;
    goto LAB103;

LAB104:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t16 = *((unsigned char *)t8);
    t17 = (t16 == (unsigned char)2);
    t13 = t17;
    goto LAB106;

LAB107:    t12 = 0;

LAB110:    if (t12 < 32U)
        goto LAB111;
    else
        goto LAB109;

LAB111:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB108;

LAB112:    t12 = (t12 + 1);
    goto LAB110;

LAB113:    xsi_set_current_line(116, ng0);
    t2 = (t0 + 6679);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 6711);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(118, ng0);
    t2 = (t0 + 3888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(119, ng0);
    t2 = (t0 + 6743);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(120, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB119:    *((char **)t1) = &&LAB120;
    goto LAB1;

LAB114:    goto LAB113;

LAB116:    goto LAB114;

LAB117:    xsi_set_current_line(121, ng0);
    t2 = (t0 + 6747);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(122, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6752);
    t14 = 1;
    if (32U == 32U)
        goto LAB132;

LAB133:    t14 = 0;

LAB134:    if (t14 == 1)
        goto LAB129;

LAB130:    t13 = (unsigned char)0;

LAB131:    if (t13 == 1)
        goto LAB126;

LAB127:    t11 = (unsigned char)0;

LAB128:    if (t11 == 1)
        goto LAB123;

LAB124:    t10 = (unsigned char)0;

LAB125:    if (t10 == 0)
        goto LAB121;

LAB122:    xsi_set_current_line(124, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB140:    *((char **)t1) = &&LAB141;
    goto LAB1;

LAB118:    goto LAB117;

LAB120:    goto LAB118;

LAB121:    t7 = (t0 + 6784);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB122;

LAB123:    t7 = (t0 + 1992U);
    t20 = *((char **)t7);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)2);
    t10 = t22;
    goto LAB125;

LAB126:    t7 = (t0 + 1832U);
    t15 = *((char **)t7);
    t18 = *((unsigned char *)t15);
    t19 = (t18 == (unsigned char)2);
    t11 = t19;
    goto LAB128;

LAB129:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t16 = *((unsigned char *)t8);
    t17 = (t16 == (unsigned char)2);
    t13 = t17;
    goto LAB131;

LAB132:    t12 = 0;

LAB135:    if (t12 < 32U)
        goto LAB136;
    else
        goto LAB134;

LAB136:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB133;

LAB137:    t12 = (t12 + 1);
    goto LAB135;

LAB138:    xsi_set_current_line(129, ng0);
    t2 = (t0 + 6790);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(130, ng0);
    t2 = (t0 + 6822);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(131, ng0);
    t2 = (t0 + 3888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(132, ng0);
    t2 = (t0 + 6854);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(133, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB144:    *((char **)t1) = &&LAB145;
    goto LAB1;

LAB139:    goto LAB138;

LAB141:    goto LAB139;

LAB142:    xsi_set_current_line(134, ng0);
    t2 = (t0 + 6858);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(135, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6863);
    t14 = 1;
    if (32U == 32U)
        goto LAB157;

LAB158:    t14 = 0;

LAB159:    if (t14 == 1)
        goto LAB154;

LAB155:    t13 = (unsigned char)0;

LAB156:    if (t13 == 1)
        goto LAB151;

LAB152:    t11 = (unsigned char)0;

LAB153:    if (t11 == 1)
        goto LAB148;

LAB149:    t10 = (unsigned char)0;

LAB150:    if (t10 == 0)
        goto LAB146;

LAB147:    xsi_set_current_line(137, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB165:    *((char **)t1) = &&LAB166;
    goto LAB1;

LAB143:    goto LAB142;

LAB145:    goto LAB143;

LAB146:    t7 = (t0 + 6895);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB147;

LAB148:    t7 = (t0 + 1992U);
    t20 = *((char **)t7);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)2);
    t10 = t22;
    goto LAB150;

LAB151:    t7 = (t0 + 1832U);
    t15 = *((char **)t7);
    t18 = *((unsigned char *)t15);
    t19 = (t18 == (unsigned char)2);
    t11 = t19;
    goto LAB153;

LAB154:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t16 = *((unsigned char *)t8);
    t17 = (t16 == (unsigned char)2);
    t13 = t17;
    goto LAB156;

LAB157:    t12 = 0;

LAB160:    if (t12 < 32U)
        goto LAB161;
    else
        goto LAB159;

LAB161:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB158;

LAB162:    t12 = (t12 + 1);
    goto LAB160;

LAB163:    xsi_set_current_line(142, ng0);
    t2 = (t0 + 6901);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(143, ng0);
    t2 = (t0 + 6933);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 3888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(145, ng0);
    t2 = (t0 + 6965);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(146, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB169:    *((char **)t1) = &&LAB170;
    goto LAB1;

LAB164:    goto LAB163;

LAB166:    goto LAB164;

LAB167:    xsi_set_current_line(147, ng0);
    t2 = (t0 + 6969);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(148, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 6974);
    t14 = 1;
    if (32U == 32U)
        goto LAB182;

LAB183:    t14 = 0;

LAB184:    if (t14 == 1)
        goto LAB179;

LAB180:    t13 = (unsigned char)0;

LAB181:    if (t13 == 1)
        goto LAB176;

LAB177:    t11 = (unsigned char)0;

LAB178:    if (t11 == 1)
        goto LAB173;

LAB174:    t10 = (unsigned char)0;

LAB175:    if (t10 == 0)
        goto LAB171;

LAB172:    xsi_set_current_line(150, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB190:    *((char **)t1) = &&LAB191;
    goto LAB1;

LAB168:    goto LAB167;

LAB170:    goto LAB168;

LAB171:    t7 = (t0 + 7006);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB172;

LAB173:    t7 = (t0 + 1992U);
    t20 = *((char **)t7);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)3);
    t10 = t22;
    goto LAB175;

LAB176:    t7 = (t0 + 1832U);
    t15 = *((char **)t7);
    t18 = *((unsigned char *)t15);
    t19 = (t18 == (unsigned char)2);
    t11 = t19;
    goto LAB178;

LAB179:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t16 = *((unsigned char *)t8);
    t17 = (t16 == (unsigned char)2);
    t13 = t17;
    goto LAB181;

LAB182:    t12 = 0;

LAB185:    if (t12 < 32U)
        goto LAB186;
    else
        goto LAB184;

LAB186:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB183;

LAB187:    t12 = (t12 + 1);
    goto LAB185;

LAB188:    xsi_set_current_line(154, ng0);
    t2 = (t0 + 7012);
    t4 = (t0 + 3696);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(155, ng0);
    t2 = (t0 + 7044);
    t4 = (t0 + 3760);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(156, ng0);
    t2 = (t0 + 3888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(157, ng0);
    t2 = (t0 + 7076);
    t4 = (t0 + 3824);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(158, ng0);
    t9 = (10 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB194:    *((char **)t1) = &&LAB195;
    goto LAB1;

LAB189:    goto LAB188;

LAB191:    goto LAB189;

LAB192:    xsi_set_current_line(159, ng0);
    t2 = (t0 + 7080);
    xsi_report(t2, 5U, 0);
    xsi_set_current_line(160, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 7085);
    t14 = 1;
    if (32U == 32U)
        goto LAB207;

LAB208:    t14 = 0;

LAB209:    if (t14 == 1)
        goto LAB204;

LAB205:    t13 = (unsigned char)0;

LAB206:    if (t13 == 1)
        goto LAB201;

LAB202:    t11 = (unsigned char)0;

LAB203:    if (t11 == 1)
        goto LAB198;

LAB199:    t10 = (unsigned char)0;

LAB200:    if (t10 == 0)
        goto LAB196;

LAB197:    xsi_set_current_line(162, ng0);
    t9 = (1 * 1000LL);
    t2 = (t0 + 3120);
    xsi_process_wait(t2, t9);

LAB215:    *((char **)t1) = &&LAB216;
    goto LAB1;

LAB193:    goto LAB192;

LAB195:    goto LAB193;

LAB196:    t7 = (t0 + 7117);
    xsi_report(t7, 6U, (unsigned char)2);
    goto LAB197;

LAB198:    t7 = (t0 + 1992U);
    t20 = *((char **)t7);
    t21 = *((unsigned char *)t20);
    t22 = (t21 == (unsigned char)2);
    t10 = t22;
    goto LAB200;

LAB201:    t7 = (t0 + 1832U);
    t15 = *((char **)t7);
    t18 = *((unsigned char *)t15);
    t19 = (t18 == (unsigned char)2);
    t11 = t19;
    goto LAB203;

LAB204:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t16 = *((unsigned char *)t8);
    t17 = (t16 == (unsigned char)2);
    t13 = t17;
    goto LAB206;

LAB207:    t12 = 0;

LAB210:    if (t12 < 32U)
        goto LAB211;
    else
        goto LAB209;

LAB211:    t5 = (t3 + t12);
    t6 = (t2 + t12);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB208;

LAB212:    t12 = (t12 + 1);
    goto LAB210;

LAB213:    xsi_set_current_line(164, ng0);
    t2 = (t0 + 7123);
    xsi_report(t2, 13U, 0);
    xsi_set_current_line(165, ng0);

LAB219:    *((char **)t1) = &&LAB220;
    goto LAB1;

LAB214:    goto LAB213;

LAB216:    goto LAB214;

LAB217:    goto LAB2;

LAB218:    goto LAB217;

LAB220:    goto LAB218;

}


extern void work_a_1599699025_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1599699025_2372691052_p_0};
	xsi_register_didat("work_a_1599699025_2372691052", "isim/ALUTest_isim_beh.exe.sim/work/a_1599699025_2372691052.didat");
	xsi_register_executes(pe);
}
